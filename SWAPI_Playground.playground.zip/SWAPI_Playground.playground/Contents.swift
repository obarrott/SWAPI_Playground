import UIKit

struct Person: Decodable {
    let name: String
    let films: [URL]
}

struct Film: Decodable {
    let title: String
    let opening_crawl: String
    let release_date: String
}


class SwapiService {
    static private let baseURL = URL(string: "http://swapi.dev/api")
    
    // MARK: - Fetch Person
    static func fetchPerson(id: Int, completion: @escaping (Person?) -> Void) {
      // 1 - Prepare URL
        guard let baseURL = baseURL else {return completion(nil)}
        let personEndpoint = "people/\(id)"
        let personURL = baseURL.appendingPathComponent(personEndpoint)
        
//        var components = URLComponents(url: personURL, resolvingAgainstBaseURL: true)
//
//        let personQuery = URLQueryItem(name: "people", value: "\(id)")
//        components?.queryItems = [personQuery]
        
//        guard let finalURL = components?.url else {return completion(nil)}
        
        let finalURL = personURL
        print(finalURL)
        
      // 2 - Contact server
        URLSession.shared.dataTask(with: finalURL) { (data, _, error) in
            //3 - Handle Errors
            if let error = error {
                print("Error in \(#function) : \(error.localizedDescription) \n---\n \(error)")
                return completion(nil)
            }
            //4 - Check for data
            guard let data = data else {return completion(nil)}
            
            //5 - Decode Person from JSON
            do {
                let person = try JSONDecoder().decode(Person.self, from: data)
                return completion(person)
            } catch {
                print("Error in \(#function) : \(error.localizedDescription) \n---\n \(error)")
                return completion(nil)
            }
        }.resume()
    }
    
    // MARK: - Fetch Film
    static func fetchFilm(url: URL, completion: @escaping (Film?) -> Void) {
        //1 - Contact server
        URLSession.shared.dataTask(with: url) { (data, _, error) in
            //2 - Handle errors
            if let error = error{
                print("Error in \(#function) : \(error.localizedDescription) \n---\n \(error)")
                return completion(nil)
            }
            //3 - Check for data
            guard let data = data else {return completion(nil)}
            
             //4 - Decode Film from JSON
            do {
                let film = try JSONDecoder().decode(Film.self, from: data)
                return completion(film)
            } catch {
                print("Error in \(#function) : \(error.localizedDescription) \n---\n \(error)")
                return completion(nil)
            }
        }.resume()
    }
}




SwapiService.fetchPerson(id: 4) { person in
    if let person = person {
        print(person.name)
        print("\nFilms:")
        for film in person.films {
            fetchFilm(url: film)
        }
    }
}


func fetchFilm(url: URL){
    SwapiService.fetchFilm(url: url) { film in
        if let film = film {
            print(film.title)
        }
    }
}
